// create an object constructor for User
function User(email, password, firstName, lastName, age, address, phone, payment, color){
    this.email = email;
    this.password = password;
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.address = address;
    this.phone = phone;
    this.payment = payment;
    this.color = color;

}
//get the inputs from the HTML using jQuery
let inputEmail = $("#txtEmail");
let inputPassword = $("#txtPassword");
let inputfirstName = $("#txtfirstName");
let inputlastName = $("#txtlastName");
let inputAge = $("#txtAge");
let inputAddress = $("#txtAddress");
let inputPhone = $("#txtPhone");
let inputPayment = $("#txtPayment");
let inputColor = $("#Color");

// create the register function
function register(){
    // create a newUser
let newUser = new User (inputEmail.val(), inputPassword.val(), inputfirstName.val(), inputlastName.val(), inputAge.val(), inputAddress.val(), inputPhone.val(), inputPayment.val(), inputColor.val());

    isValid(Users);
    //display the user on the console
    saveUser(newUser); // this function is under storeManager

    //********HINT: add the onclick event on the button (register.html) */
}





function init(){

    //hook events
    // $("#stnAdd").onclick(register)
    $("#btnAdd").on('click',register)
    isValid(Users)
    // $('input') .on('mouseover', function(){
    //     $(this).css({'background-color': '#dedede'});
    // });
    // $('input') .on('mouseleave', function(){
    //     $(this).css({'background-color': 'white'});

    // });
    // challenge: if the mouse is over the header section change the color of the main
//     $('header') .on('mouseover', function(){
//     $(this).css({'background-color': '#dedede'});
//     });
// $('header') .on('mouseleave', function(){
//     $(this).css({'background-color': 'white'});

// });
}

window.onload=init;