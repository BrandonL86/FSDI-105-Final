function login(){
    console.log("login")
 // get the values from the HTML inputs
let inputEmail= $("#txtEmail").val();
let inputPassword = $("#txtPassword").val();
console.log(inputEmail, inputPassword);
  // get the users from LS
let users = readUsers();
    //for loop to travel the array (we were doing it under users.js)
    for(let i =0; i < users.length; i++) {
        let user = users[i];
        console.log (users)
        if(inputEmail == user.email && inputPassword == user.password){
            window.location="users.html";
            console.log("Welcome");
        }else{
            console.log("invalid credentials");
        }
     }
    }
   

function init(){
    // hook event
    $("#loginbtn").click(login);

}

window.onload=init;