const KEY = "users";
function saveUser(user){
    let userArray = readUsers();
    userArray.push(user);
    let val = JSON.stringify(userArray);// it parse the obj into string
    localStorage.setItem(KEY, val);// this send the val to the LS
    console.log("The user was sent to the LS");
}

function readUsers(){
    let data = localStorage.getItem(KEY); // it gets from LS the data under "users"
    
    if (!data){ //NOT data?
        //if you get here it means
        return[];
        // console.log("The LS is empty");
    }else{
        let userList = JSON.parse(data);
        return userList;
        // console.log("The LS has data");
    }

}