function displayUsers(usersArray){
    let tr ="";
    const TABLE = document.getElementById("usersTable");

    for (let i=0; i < usersArray.length; i++){
        let usersX = usersArray[i];
        tr+=`
        <tr id="${usersX.id}" class="table-row">
                    <td>${usersX.email}</td>
                    <td>${usersX.password}</td>
                    <td>${usersX.firstName}</td>
                    <td>${usersX.lastName}</td>
                    <td>${usersX.age}</td>
                    <td>${usersX.address}</td>
                    <td>${usersX.phone}</td>
                    <td>${usersX.payment}</td>
                    <td>${usersX.color}</td>
                </tr>
        `;
    }
    TABLE.innerHTML = tr;
}


function isValid(Users)
{
    let valid = true;

    if(Users.email == ""){   
        valid = false;
        inputEmail.classList.add("Error");
    }
    if(Users.password == ""){
        valid=false;
        inputPassword.classList.add("Error");
    }
    if(Users.firstName == ""){
        valid=false;
        inputfirstName.classList.add("Error");
    }
    if(Users.lastName == ""){
        valid=false;
        inputlastName.classList.add("Error");
    }
    if(Users.age == ""){
        valid=false;
        inputAge.classList.add("Error");
    }
    if(Users.address == ""){
        valid=false;
        inputAddress.classList.add("Error");
    }
    if(Users.phone == ""){
        valid=false;
        inputPhone.classList.add("Error");
    }
    if(Users.payment == ""){
        valid=false;
        inputPayment.classList.add("Error");
    }
    if(Users.color == ""){
        valid=false;
        inputColor.classList.add("Error");
    }
    return valid;

}

// function clearInputs(){
//     inputEmail.value="";
//     inputPassword.value = "";
//     inputfirstName.value = "";
//     inputlastName.value = "";
//     inputAge.value = "";
//     inputAddress.value = "";
//     inputPhone.value = "";
//     inputPayment.value = "";
//     inputColor.value = "";
// }

function init(){
    // console.log("Listing users");
    let users = readUsers();
    displayUsers(users);
    
}

window.onload=init;